java -jar /opt/SecureSignIn/SecureSignIn-3.3.jar
