java -jar /opt/SecureSignIn/SecureSignIn-3.5b.jar
